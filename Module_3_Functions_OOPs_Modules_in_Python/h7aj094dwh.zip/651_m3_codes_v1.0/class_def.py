a=30
def add(b):
    c=30
    print("c= ",c)
    sum=b+c
    print("Addition is :",sum)


print(a)
add(40)
print(c)

a=50
class Edureka():
    b=60
    print(b)

ob=Edureka()