def print_name(str):
    print("Welcome to Python, ",str)
    return()


str=input("Enter your name :")
print_name(str)

