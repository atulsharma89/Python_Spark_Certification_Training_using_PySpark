#Creating a Class
class number():
    pass

#Creating Instance of Class
x=number()
print(x)

