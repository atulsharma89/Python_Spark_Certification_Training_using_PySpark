def info(name,age=50):
    print("Name: ",name)
    print("Age :",age)
    return()

info(age=25,name="Annie")
info(name="Miki")

# Another Example
def employee(name,id,salary=10000):
    print("Name of Employee: ",name)
    print("ID no of Employee: ",id)
    print("Salary of Employe: ",salary)

employee("Sara",101,20000)
employee("Alex",98)
