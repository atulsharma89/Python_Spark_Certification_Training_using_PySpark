a=50
def number():
    b=30
    print(b)

print(a)
number()



a=30
def add(b):
    c=30
    print("c=",c)
    sum=b+c
    print("Addition is: ",sum)

print(a)
add(40)
print(c)