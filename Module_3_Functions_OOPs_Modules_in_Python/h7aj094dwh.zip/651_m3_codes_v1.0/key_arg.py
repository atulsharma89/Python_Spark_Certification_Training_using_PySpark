def Welcome(str):
    print("Welcome to Python, ",str)
    return()

Welcome(str="Annie")


#Another Example
def add(a,b,c,d):
    print(a)
    print(b)
    print(c)
    print(d)
    sum=a+b+c+d
    return(sum)

ans=add(d=10,a=50,c=5,b=5)
print("Sum is : ",ans)

