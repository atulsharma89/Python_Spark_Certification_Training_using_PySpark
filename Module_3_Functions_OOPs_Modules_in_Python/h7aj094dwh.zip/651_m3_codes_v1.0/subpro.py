import subprocess
check=subprocess.call('ls',1)