def add(a,b):
    sum=a+b
    return (sum)

num1=input("Enter first number")
num2=input("Enter second number")
n1=int(num1)
n2=int(num2)
ans=add(n1,n2)
print("Addition of 2 number is:",ans)