a=10
b=20
print(id(a))
print(id(b))