class Edureka():
    def Hello(self):
        print("Happy Learning")

ob=Edureka()
ob.Hello()

