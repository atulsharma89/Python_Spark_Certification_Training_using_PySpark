a=50
b=a/0
print(b)



