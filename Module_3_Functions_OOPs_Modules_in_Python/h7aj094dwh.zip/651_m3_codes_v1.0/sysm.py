import sys

print(not sys)

print(sys.winver)

print(sys.flags)

print(sys.prefix)


print(sys.argv)

print(sys.exit())



