A={'Age':24, 'Name':'John'}

print(A)