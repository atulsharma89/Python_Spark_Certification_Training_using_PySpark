count=0
while(count<5):
    print(count)
    count=count+1

print("Good bye!")

#Example
rank=5
while(rank!=12):
    print("Rank is ",rank)
    rank+=1